game.import('extension', function (lib, game, ui, get, ai, _status) {
    return {
        name: '武将娘化',
        editable: false,
        content: function (config, pack) {
            lib.rank.rarity.legend.push('nv_xusheng');
            lib.rank.rarity.legend.push('nv_ganning');
            lib.rank.rarity.legend.push('nv_huangzhong');
            lib.rank.rarity.legend.push('nv_guojia');
            lib.rank.rarity.legend.push('nv_xunyu');
            lib.rank.rarity.legend.push('nv_sunquan');
            lib.rank.rarity.legend.push('nv_zhangliao');
            lib.rank.rarity.legend.push('nv_zhonghui');
            lib.rank.rarity.legend.push('nv_jiangwei');

            lib.namePrefix.set('女', {color: 'pink', nature: 'firemm'});

        },
        precontent: function () {
            //加载卡包
            game.import('card', function () {
                var nv_wujiang = {
                    name: 'nv_wujiang',
                    connect: true,
                    card: {
                        qizhengxiangsheng: {
                            enable: true,
                            type: 'trick',
                            fullskin: true,
                            derivation: 'shen_xunyu',
                            filterTarget: lib.filter.notMe,
                            content: function () {
                                'step 0'
                                if (!event.qizheng_name) {
                                    if (player.isIn()) player.chooseControl('奇兵', '正兵').set('prompt', '请选择' + get.translation(target) + '的标记').set('choice', function () {
                                        var e1 = 1.5 * get.sgn(get.damageEffect(target, player, target));
                                        var e2 = 0;
                                        if (target.countGainableCards(player, 'h') > 0 && !target.hasSkillTag('noh')) e2 = -1;
                                        var es = target.getGainableCards(player, 'e');
                                        if (es.length) e2 = Math.min(e2, function () {
                                            var max = 0;
                                            for (var i of es) max = Math.max(max, get.value(i, target))
                                            return -max / 4;
                                        }());
                                        if (Math.abs(e1 - e2) <= 0.3) return Math.random() < 0.5 ? '奇兵' : '正兵';
                                        if (e1 < e2) return '奇兵';
                                        return '正兵';
                                    }()).set('ai', function () {
                                        return _status.event.choice;
                                    });
                                    else event.finish();
                                }
                                'step 1'
                                if (!event.qizheng_name && result && result.control) event.qizheng_name = result.control;
                                if (event.directHit) event._result = {bool: false};
                                else target.chooseToRespond('请打出一张杀或闪响应奇正相生', function (card, player) {
                                    var name = get.name(card);
                                    return name == 'sha' || name == 'shan';
                                }).set('ai', function (card) {
                                    if (_status.event.choice == 'all') {
                                        var rand = get.rand('qizhengxiangsheng');
                                        if (rand > 0.5) return 0;
                                        return 1 + Math.random();
                                    }
                                    if (get.name(card) == _status.event.choice) return get.order(card);
                                    return 0;
                                }).set('choice', function () {
                                    if (target.hasSkillTag('useShan')) return 'shan';
                                    if (typeof event.qizheng_aibuff == 'boolean') {
                                        var shas = target.getCards('h', 'sha'), shans = target.getCards('h', 'shan');
                                        if (event.qizheng_aibuff) {
                                            if (shas.length >= Math.max(1, shans.length)) return 'shan';
                                            if (shans.length > shas.length) return 'sha';
                                            return false;
                                        }
                                        if (!shas.length || !shans.length) return false;
                                    }
                                    var e1 = 1.5 * get.sgn(get.damageEffect(target, player, target));
                                    var e2 = 0;
                                    if (target.countGainableCards(player, 'h') > 0 && !target.hasSkillTag('noh')) e2 = -1;
                                    var es = target.getGainableCards(player, 'e');
                                    if (es.length) e2 = Math.min(e2, function () {
                                        var max = 0;
                                        for (var i of es) max = Math.max(max, get.value(i, target))
                                        return -max / 4;
                                    }());
                                    if (e1 - e2 >= 0.3) return 'shan';
                                    if (e2 - e1 >= 0.3) return 'sha';
                                    return 'all';
                                }());
                                'step 2'
                                var name = result.bool ? result.card.name : null, require = event.qizheng_name;
                                if (require == '奇兵' && name != 'sha') target.damage();
                                else if (require == '正兵' && name != 'shan' && target.countGainableCards(player, 'he') > 0) player.gainPlayerCard(target, true, 'he');
                            },
                            ai: {
                                order: 5,
                                tag: {
                                    damage: 0.5,
                                    gain: 0.5,
                                    loseCard: 1,
                                    respondShan: 1,
                                    respondSha: 1,
                                },
                                result: {
                                    target: function (player, target) {
                                        var e1 = 1.5 * get.sgn(get.damageEffect(target, player, target));
                                        var e2 = 0;
                                        if (target.countGainableCards(player, 'h') > 0 && !target.hasSkillTag('noh')) e2 = -1;
                                        var es = target.getGainableCards(player, 'e');
                                        if (es.length) e2 = Math.min(e2, function () {
                                            var max = 0;
                                            for (var i of es) max = Math.max(max, get.value(i, target))
                                            return -max / 4;
                                        }());
                                        if (game.hasPlayer(function (current) {
                                            return current.hasSkill('tianzuo') && get.attitude(current, player) <= 0;
                                        })) return Math.max(e1, e2);
                                        return Math.min(e1, e2);
                                    },
                                },
                            },
                        },
                    },
                    skill: {}, // 技能
                    translate: {
                        qizhengxiangsheng: '奇正相生',
                        qizhengxiangsheng_info: '出牌阶段，对一名其他角色使用。你将目标角色标记为“奇兵”或“正兵”（对其他角色不可见）。然后目标角色可以打出一张【杀】或【闪】。若其是“奇兵”且未打出【杀】，则你对其造成1点伤害；若其是“正兵”且未打出【闪】，则你获得其一张牌。',
                    }, // 翻译
                    list: [], // 牌堆添加
                };
                return nv_wujiang;
            });
            lib.translate['nv_wujiang_card_config'] = '卡包名';
            lib.config.all.cards.push('nv_wujiang');
            if (!lib.config.cards.contains('nv_wujiang')) lib.config.cards.push('nv_wujiang');

            // 加载武将包
            game.import('character', function () {
                var nv_wujiang = {
                    name: 'nv_wujiang',
                    connect: true,
                    character: {
                        nv_xusheng: ['female', 'wu', 4, ['nv_pojun', 'nv_xushi', 'mashu'], []],
                        nv_ganning: ['female', 'shen', 6, ['nv_poxi', 'nv_jieying'], ['wu']],
                        nv_huangzhong: ['female', 'shu', 4, ['nv_liegong'], []],
                        nv_guojia: ['female', 'shen', 3, ['nv_huishi', 'nv_huishiPlus', 'nv_tianyi'], ['wei']],
                        nv_xunyu: ['female', 'shen', 3, ['tianzuo', 'nv_lingce', 'nv_dinghan'], ['wei']],
                        nv_sunquan: ['female', 'wu', 4, ['nv_huiwan', 'sbjiuyuan'], []],
                        nv_zhangliao: ['female', 'shen', 4, ['nv_duorui'], ['wei']],
                        nv_zhonghui: ['female', 'wei', 3, ['nv_quanji', 'nv_paiyi', 'nv_bidang'], []],
                        nv_jiangwei: ['female', 'shen', 3, ['tianren', 'jiufa', 'nv_pingxiang'], ['shu']],
                        // 武将格式:
                        // "武将名字": ["性别", "势力", 体力, [技能], []],
                        // 格式内每一样东西都不能缺少，否则无法导入该武将包及其以下内容
                    },
                    characterIntro: {}, // 武将介绍（选填）
                    characterTitle: {}, // 武将标题（用于写称号或注释）（选填）
                    skill: {
                        nv_pojun: {
                            audio: 'repojun',
                            shaRelated: true,
                            trigger: {
                                player: 'useCardToPlayered',
                            },
                            direct: true,
                            filter: function (event, player) {
                                return event.card.name == 'sha' && event.target.countCards('he') > 0;
                            },
                            content: function () {
                                'step 0'
                                player.choosePlayerCard(trigger.target, 'he',
                                    [1, Math.min(trigger.target.countCards('he'), trigger.target.maxHp)], get.prompt('nv_pojun', trigger.target)
                                ).set('forceAuto', true).set('goon', get.attitude(player, trigger.target) <= 0).set('ai', function (button) {
                                    if (!_status.event.goon) return 0;
                                    var val = get.value(button.link);
                                    if (button.link == _status.event.target.getEquip(2)) return 2 * (val + 3);
                                    return val;
                                });
                                'step 1'
                                if (result.bool && result.links.length) {
                                    player.logSkill('nv_pojun', target);
                                    player.gain(result.links, 'gain2');
                                    trigger.target.addMark('nv_pojun', result.links.length);
                                    trigger.target.storage.debt = player;
                                    trigger.target.addTempSkill('nv_pojun_give', {player: 'dieAfter'});
                                }
                            },
                            marktext: '破',
                            intro: {
                                name: '破军',
                                content: '被抢了#张牌',
                            },
                            group: 'nv_pojun_dmg',
                            subSkill: {
                                dmg: {
                                    sub: true,
                                    trigger: {
                                        source: 'damageBegin1',
                                    },
                                    direct: true,
                                    locked: true,
                                    logTarget: 'player',
                                    filter: function (event, player) {
                                        var target = event.player;
                                        return event.getParent().name == 'sha' && player.countCards('h') >= target.countCards('h');
                                    },
                                    content: function () {
                                        trigger.num++;
                                    },
                                },
                                give: {
                                    sub: true,
                                    forced: true,
                                    charlotte: true,
                                    popup: false,
                                    trigger: {
                                        global: ['phaseUseAfter', 'phaseDiscardBefore', 'phaseAfter'],
                                    },
                                    filter: function (event, player) {
                                        return player.hasMark('nv_pojun');
                                    },
                                    content: function () {
                                        'step 0'
                                        if (player.storage.debt.countCards('he') == 0) event.goto(3);
                                        'step 1'
                                        player.storage.debt.chooseCard('he', Math.min(player.storage.debt.countCards('he'), player.countMark('nv_pojun')), true, '请选择要还给' + get.translation(player) + '的牌').set('ai', function (card) {
                                            return 5 - get.value(card);
                                        });
                                        'step 2'
                                        if (result.cards) {
                                            player.storage.debt.give(result.cards, player, false);
                                        }
                                        'step 3'
                                        player.removeMark('nv_pojun', player.countMark('nv_pojun'));
                                        player.removeSkill('nv_pojun_give');
                                    },
                                },
                            },
                            ai: {
                                'unequip_ai': true,
                                'directHit_ai': true,
                                threaten: 2.5,
                                skillTagFilter: function (player, tag, arg) {
                                    if (get.attitude(player, arg.target) > 0) return false;
                                    if (tag == 'directHit_ai') return arg.target.maxHp >= Math.max(1, arg.target.countCards('h') - 1);
                                    if (arg && arg.name == 'sha' && arg.target.getEquip(2)) return true;
                                    return false;
                                },
                            },
                        },
                        nv_xushi: {
                            audio: 'pojun',
                            frequent: true,
                            trigger: {
                                player: 'phaseJieshuBegin',
                            },
                            filter: function (event, player) {
                                return !player.getStat('damage');
                            },
                            content: function () {
                                player.changeHujia(1);
                                var card = get.cardPile(function (card) {
                                    return card.name == 'sha';
                                });
                                if (!card) card = get.discardPile(function (card) {
                                    return card.name == 'sha';
                                });
                                player.gain(card, 'gain2', false);
                                if (!player.hasSkill('nv_xushi_eff')) {
                                    player.addSkill('nv_xushi_eff');
                                } else {
                                    if (!player.storage.nv_xushi_eff) player.storage.nv_xushi_eff = 0;
                                }
                                player.addMark('nv_xushi_eff');
                            },
                            subSkill: {
                                eff: {
                                    marktext: '势',
                                    mark: true,
                                    sub: true,
                                    intro: {
                                        name: '蓄势',
                                        content: '可令下一张【杀】的伤害基数+#',
                                    },
                                    trigger: {
                                        player: 'useCard',
                                    },
                                    filter: function (event) {
                                        return event.card && event.card.name == 'sha';
                                    },
                                    prompt: function (event, player, storage) {
                                        return '是否令此【杀】的伤害值基数+' + player.storage.nv_xushi_eff + '？';
                                    },
                                    content: function () {
                                        if (!trigger.baseDamage) trigger.baseDamage = 1;
                                        trigger.baseDamage += player.storage.nv_xushi_eff;
                                        game.log('此', trigger.card, '的伤害+', player.storage.nv_xushi_eff);
                                        player.removeSkill('nv_xushi_eff');
                                    },
                                    init: function (player) {
                                        player.storage.nv_xushi_eff = 0;
                                    },
                                    onremove: function (player) {
                                        delete player.storage.nv_xushi_eff;
                                    },
                                    ai: {
                                        damageBonus: true,
                                    },
                                },
                            },
                        },
                        nv_poxi: {
                            audio: 'drlt_poxi',
                            enable: 'phaseUse',
                            usable: 1,
                            filterTarget: function (card, player, target) {
                                return target != player && target.countCards('h') > 0;
                            },
                            content: function () {
                                'step 0'
                                event.list1 = [];
                                event.list2 = [];
                                if (player.countCards('h') > 0) {
                                    var chooseButton = player.chooseButton(4, ['你的手牌', player.getCards('h'), get.translation(target.name) + '的手牌', target.getCards('h')]);
                                } else {
                                    var chooseButton = player.chooseButton(4, [get.translation(target.name) + '的手牌', target.getCards('h')]);
                                }
                                chooseButton.set('target', target);
                                chooseButton.set('ai', function (button) {
                                    var player = _status.event.player;
                                    var target = _status.event.target;
                                    var ps = [];
                                    var ts = [];
                                    for (var i = 0; i < ui.selected.buttons.length; i++) {
                                        var card = ui.selected.buttons[i].link;
                                        if (target.getCards('h').contains(card)) ts.push(card);
                                        else ps.push(card);
                                    }
                                    var card = button.link;
                                    var owner = get.owner(card);
                                    var val = get.value(card) || 1;
                                    if (owner == target) {
                                        if (ts.length > 1) return 0;
                                        if (ts.length == 0 || player.hp > 3) return val;
                                        return 2 * val;
                                    }
                                    return 7 - val;
                                });
                                chooseButton.set('filterButton', function (button) {
                                    if (ui.selected.buttons.length >= 4) return false;
                                    return true;
                                });
                                'step 1'
                                if (result.bool) {
                                    var list = result.links;
                                    for (var i = 0; i < list.length; i++) {
                                        if (get.owner(list[i]) == player) {
                                            event.list1.push(list[i]);
                                        } else {
                                            event.list2.push(list[i]);
                                        }
                                        ;
                                    }
                                    ;
                                    if (event.list1.length && event.list2.length) {
                                        game.loseAsync({
                                            lose_list: [
                                                [player, event.list1],
                                                [target, event.list2]
                                            ],
                                            discarder: player,
                                        }).setContent('discardMultiple');
                                    } else if (event.list2.length) {
                                        target.discard(event.list2);
                                    } else player.discard(event.list1);
                                }
                                ;
                                'step 2'
                                if (event.list1.length + event.list2.length == 4) {
                                    if (event.list1.length == 0) player.loseHp();
                                    if (event.list1.length == 1) player.addTempSkill('nv_poxi_debuff', {player: 'phaseAfter'});
                                    if (event.list1.length == 2) {
                                        player.addTempSkill('nv_poxi_more');
                                        player.addMark('nv_poxi_more', 1, false);
                                    }
                                    if (event.list1.length == 3) {
                                        player.recover();
                                        player.changeHujia(1);
                                    }
                                    if (event.list1.length == 4) player.draw(5);
                                }
                                ;
                            },
                            ai: {
                                order: 13,
                                result: {
                                    target: function (target, player) {
                                        return -1;
                                    },
                                },
                            },
                            subSkill: {
                                debuff: {
                                    sub: true,
                                    charlotte: true,
                                    mod: {
                                        maxHandcard: function (player, num) {
                                            return num - 1;
                                        },
                                    },
                                },
                                more: {
                                    charlotte: true,
                                    onremove: true,
                                    mod: {
                                        cardUsable: function (card, player, num) {
                                            if (card.name == 'sha') return num + player.countMark('nv_poxi_more');
                                        },
                                    },
                                    sub: true,
                                },
                            },
                        },
                        nv_jieying_mark: {
                            marktext: '营',
                            intro: {
                                name: '营',
                                content: 'mark',
                            },
                            mod: {
                                cardUsable: function (card, player, num) {
                                    if (player.hasMark('nv_jieying_mark') && card.name == 'sha') return num + game.countPlayer(function (current) {
                                        return current.hasSkill('nv_jieying');
                                    });
                                },
                                maxHandcard: function (player, num) {
                                    if (player.hasMark('nv_jieying_mark')) return num + game.countPlayer(function (current) {
                                        return current.hasSkill('nv_jieying');
                                    });
                                },
                            },
                            audio: 'drlt_jieying',
                            trigger: {
                                player: 'phaseDrawBegin2',
                            },
                            forced: true,
                            filter: function (event, player) {
                                return !event.numFixed && player.hasMark('nv_jieying_mark') && game.hasPlayer(function (current) {
                                    return current.hasSkill('nv_jieying');
                                });
                            },
                            content: function () {
                                trigger.num += game.countPlayer(function (current) {
                                    return current.hasSkill('nv_jieying');
                                });
                            },
                            ai: {
                                nokeep: true,
                                skillTagFilter: function (player) {
                                    if (!player.hasMark('nv_jieying_mark')) return false;
                                },
                            },
                        },
                        nv_jieying: {
                            audio: 'drlt_jieying',
                            locked: false,
                            global: 'nv_jieying_mark',
                            group: ['nv_jieying_1', 'nv_jieying_2', 'nv_jieying_3'],
                            subSkill: {
                                '1': {
                                    audio: 'drlt_jieying',
                                    trigger: {
                                        player: 'phaseBegin',
                                    },
                                    forced: true,
                                    filter: function (event, player) {
                                        return !game.hasPlayer(function (current) {
                                            return current.hasMark('nv_jieying_mark');
                                        });
                                    },
                                    content: function () {
                                        player.addMark('nv_jieying_mark', 1);
                                    },
                                    sub: true,
                                },
                                '2': {
                                    audio: 'drlt_jieying',
                                    trigger: {
                                        player: 'phaseJieshuBegin',
                                    },
                                    direct: true,
                                    filter: function (event, player) {
                                        return player.hasMark('nv_jieying_mark');
                                    },
                                    content: function () {
                                        'step 0'
                                        player.chooseTarget(get.prompt('nv_jieying'), '将“营”交给一名角色；其摸牌阶段多摸一张牌，出牌阶段使用【杀】的次数上限+1且手牌上限+1。该角色回合结束后，其移去“营”标记，然后你获得其所有手牌。', function (card, player, target) {
                                            return target != player;
                                        }).ai = function (target) {
                                            if (get.attitude(player, target) > 0)
                                                return 0.1;
                                            if (get.attitude(player, target) < 1 && (target.isTurnedOver() || target.countCards('h') < 1))
                                                return 0.2;
                                            if (get.attitude(player, target) < 1 && target.countCards('h') > 0 && target.countCards('j', {name: 'lebu'}) > 0)
                                                return target.countCards('h') * 0.8 + target.getHandcardLimit() * 0.7 + 2;
                                            if (get.attitude(player, target) < 1 && target.countCards('h') > 0)
                                                return target.countCards('h') * 0.8 + target.getHandcardLimit() * 0.7;
                                            return 1;
                                        };
                                        'step 1'
                                        if (result.bool) {
                                            var target = result.targets[0];
                                            player.line(target);
                                            player.logSkill('nv_jieying', target);
                                            var mark = player.countMark('nv_jieying_mark');
                                            player.removeMark('nv_jieying_mark', mark);
                                            target.addMark('nv_jieying_mark', mark);
                                        }
                                        ;
                                    },
                                    sub: true,
                                },
                                '3': {
                                    audio: 'drlt_jieying',
                                    trigger: {
                                        global: ['phaseUseAfter', 'phaseDiscardBefore', 'phaseAfter'],
                                    },
                                    forced: true,
                                    direct: true,
                                    filter: function (event, player) {
                                        return player != event.player && event.player.hasMark('nv_jieying_mark') && event.player.isIn();
                                    },
                                    logTarget: 'player',
                                    content: function () {
                                        if (trigger.player.countCards('h') > 0) {
                                            player.logSkill('nv_jieying', trigger.player);
                                            trigger.player.give(trigger.player.getCards('h'), player);
                                        }
                                        if (trigger.name == 'phase') {
                                            trigger.player.removeMark('nv_jieying_mark', trigger.player.countMark('nv_jieying_mark'));
                                        }
                                    },
                                    sub: true,
                                },
                            },
                        },
                        nv_liegong: {
                            audio: 'sbliegong',
                            intro: {
                                content: '当前拥有#个[烈]标记',
                                onunmark: true,
                            },
                            mod: {
                                targetInRange: function (card) {
                                    return true;
                                },
                                cardUsable: function (card, player, num) {
                                    if (card.name == 'sha') return Math.max(num, player.countMark('nv_liegong'));
                                },
                            },
                            filter: function (event, player) {
                                return event.card.name == 'sha';
                            },
                            trigger: {
                                player: 'useCard',
                            },
                            check: function (event, player) {
                                return get.attitude(player, event.target) <= 0;
                            },
                            content: function () {
                                trigger.baseDamage += player.countMark('nv_liegong');
                                trigger.directHit.addArray(game.players);
                            },
                            ai: {
                                'directHit_ai': true,
                                threaten: 4,
                            },
                            group: ['nv_liegong_count', 'nv_liegong_clear'],
                            subSkill: {
                                count: {
                                    trigger: {
                                        player: 'useCardBefore',
                                    },
                                    frequent: true,
                                    filter: function (event, player) {
                                        return player.countMark('nv_liegong') < 3;
                                    },
                                    content: function () {
                                        player.addMark('nv_liegong', 1);
                                    },
                                    sub: true,
                                },
                                clear: {
                                    trigger: {
                                        global: 'phaseAfter',
                                    },
                                    popup: false,
                                    frequent: true,
                                    content: function () {
                                        player.draw(player.countMark('nv_liegong'));
                                        player.removeMark('nv_liegong', player.countMark('nv_liegong'));
                                    },
                                    sub: true,
                                },
                            },
                        },
                        nv_huishi: {
                            audio: 'shuishi',
                            enable: 'phaseUse',
                            usable: 1,
                            filter: function (event, player) {
                                return player.maxHp < 10;
                            },
                            content: function () {
                                'step 0'
                                event.cards = [];
                                event.suits = [];
                                'step 1'
                                player.judge(function (result) {
                                    var evt = _status.event.getParent('nv_huishi');
                                    if (evt && evt.suits && evt.suits.contains(get.suit(result))) return 0;
                                    return 1;
                                }).set('callback', lib.skill.nv_huishi.callback).judge2 = function (result) {
                                    return result.bool ? true : false;
                                };
                                'step 2'
                                var cards = cards.filterInD();
                                if (cards.length) player.chooseTarget('将' + get.translation(cards) + '交给一名角色', true).set('ai', function (target) {
                                    var player = _status.event.player;
                                    var att = get.attitude(player, target) / Math.sqrt(1 + target.countCards('h'));
                                    if (target.hasSkillTag('nogain')) att /= 10;
                                    return att;
                                });
                                else event.finish();
                                'step 3'
                                if (result.bool) {
                                    var target = result.targets[0];
                                    event.target = target;
                                    player.line(target, 'green');
                                    target.gain(cards, 'gain2').set('giver', player).gaintag = ['nv_huishi'];
                                    target.addTempSkill('nv_huishi_clr');
                                } else event.finish();
                                'step 4'
                                if (target.isMaxHandcard()) player.loseMaxHp();
                            },
                            callback: function () {
                                'step 0'
                                var evt = event.getParent(2);
                                event.getParent().orderingCards.remove(event.judgeResult.card);
                                evt.cards.push(event.judgeResult.card);
                                if (event.getParent().result.bool && player.maxHp < 10) {
                                    evt.suits.push(event.getParent().result.suit);
                                    player.gainMaxHp();
                                    player.recover(1);
                                    player.chooseBool('是否继续发动【慧识】？').set('frequentSkill', 'nv_huishi');
                                } else event._result = {bool: false};
                                'step 1'
                                if (result.bool) event.getParent(2).redo();
                            },
                            ai: {
                                order: 9,
                                result: {
                                    player: 1,
                                },
                            },
                            subSkill: {
                                clr: {
                                    mod: {
                                        ignoredHandcard: function (card, player) {
                                            if (card.hasGaintag('nv_huishi')) {
                                                return true;
                                            }
                                        },
                                    },
                                    onremove: function (player) {
                                        player.removeGaintag('nv_huishi');
                                    },
                                    sub: true,
                                    forced: true,
                                    charlotte: true,
                                },
                            },
                        },
                        nv_huishiPlus: {
                            audio: 'sghuishi',
                            enable: 'phaseUse',
                            limited: true,
                            skillAnimation: true,
                            animationColor: 'water',
                            filterTarget: true,
                            content: function () {
                                'step 0'
                                player.awakenSkill('nv_huishiPlus');
                                var list = target.getSkills(null, false, false).filter(function (skill) {
                                    var info = lib.skill[skill];
                                    return info && info.juexingji;
                                });
                                if (list.length) {
                                    target.addMark('nv_huishiPlus', 1, false);
                                    for (var i of list) {
                                        var info = lib.skill[i];
                                        if (info.filter && !info.nv_huishiPlus_filter) {
                                            info.nv_huishiPlus_filter = info.filter;
                                            info.filter = function (event, player) {
                                                if (player.hasMark('nv_huishiPlus')) return true;
                                                return this.nv_huishiPlus_filter.apply(this, arguments);
                                            }
                                        }
                                    }
                                } else target.draw(4);
                                player.loseMaxHp(2);
                            },
                            intro: {
                                content: '发动觉醒技时无视条件',
                            },
                            ai: {
                                order: 0.1,
                                expose: 0.2,
                                result: {
                                    target: function (player, target) {
                                        if (player.hasUnknown() || player.maxHp < 5) return 0;
                                        var list = target.getSkills(null, false, false).filter(function (skill) {
                                            var info = lib.skill[skill];
                                            return info && info.juexingji;
                                        });
                                        if (list.length || target.hasJudge('lebu') || target.hasSkillTag('nogain')) return 0;
                                        return 4;
                                    },
                                },
                            },
                            mark: true,
                            init: (player, skill) => player.storage[skill] = false,
                        },
                        nv_tianyi: {
                            audio: 'stianyi',
                            trigger: {
                                player: 'phaseZhunbeiBegin',
                            },
                            forced: true,
                            juexingji: true,
                            skillAnimation: true,
                            animationColor: 'gray',
                            filter: function (event, player) {
                                return !game.hasPlayer(function (current) {
                                    return current.getAllHistory('damage').length == 0;
                                });
                            },
                            content: function () {
                                'step 0'
                                player.awakenSkill('nv_tianyi');
                                player.gainMaxHp(2);
                                player.recover();
                                'step 1'
                                player.chooseTarget(true, '令一名角色获得技能〖佐幸〗').set('ai', function (target) {
                                    return get.attitude(_status.event.player, target);
                                });
                                'step 2'
                                if (result.bool) {
                                    var target = result.targets[0];
                                    player.line(target, 'green');
                                    target.storage.nv_zuoxing = player;
                                    target.addSkill('nv_zuoxing');
                                }
                            },
                            derivation: 'nv_zuoxing',
                        },
                        nv_zuoxing: {
                            audio: 'zuoxing',
                            enable: 'phaseUse',
                            usable: 1,
                            filter: function (event, player) {
                                var target = player.storage.nv_zuoxing;
                                if (!target || !target.isIn() || target.maxHp < 2) return false;
                                return true;
                            },
                            chooseButton: {
                                dialog: function (event, player) {
                                    var list = [['基本', '', 'sha'], ['基本', '', 'sha', 'thunder'], ['基本', '', 'sha', 'fire'], ['基本', '', 'sha', 'ice'], ['基本', '', 'sha', 'kami'], ['基本', '', 'sha', 'stab'], ['基本', '', 'shan'], ['基本', '', 'tao'], ['基本', '', 'jiu']];
                                    for (var i of lib.inpile) {
                                        if (get.type(i) == 'trick' && event.filterCard({
                                            name: i,
                                            isCard: true
                                        }, player, event)) list.push(['锦囊', '', i]);
                                    }
                                    return ui.create.dialog('佐幸', [list, 'vcard']);
                                },
                                check: function (button) {
                                    return _status.event.player.getUseValue({
                                        name: button.link[2],
                                        nature: button.link[3],
                                        isCard: true
                                    });
                                },
                                backup: function (links, player) {
                                    return {
                                        viewAs: {
                                            name: links[0][2],
                                            nature: links[0][3],
                                            isCard: true,
                                        },
                                        filterCard: () => false,
                                        selectCard: -1,
                                        popname: true,
                                        precontent: function () {
                                            player.logSkill('nv_zuoxing');
                                            var target = player.storage.nv_zuoxing;
                                            target.loseMaxHp();
                                        },
                                    }
                                },
                                prompt: function (links, player) {
                                    return '请选择' + get.translation({
                                        name: links[0][2],
                                        nature: links[0][3],
                                        isCard: true
                                    }) + '的目标';
                                },
                            },
                            ai: {
                                order: 1,
                                result: {
                                    player: 1,
                                },
                            },
                        },
                        nv_tianzuo: {
                            audio: 'tianzuo',
                            trigger: {
                                global: 'phaseBefore',
                                player: 'enterGame',
                            },
                            forced: true,
                            filter: function (event, player) {
                                return (event.name != 'phase' || game.phaseNumber == 0) && !lib.inpile.contains('qizhengxiangsheng');
                            },
                            content: function () {
                                game.addGlobalSkill('nv_tianzuo_global');
                                for (var i = 2; i < 10; i++) {
                                    var card = game.createCard2('qizhengxiangsheng', i % 2 ? 'club' : 'spade', i);
                                    ui.cardPile.insertBefore(card, ui.cardPile.childNodes[get.rand(0, ui.cardPile.childNodes.length)]);
                                }
                                game.broadcastAll(function () {
                                    lib.inpile.add('qizhengxiangsheng')
                                });
                                game.updateRoundNumber();
                            },
                            group: ['nv_tianzuo_remove', 'nv_tianzuo_rewrite'],
                            subSkill: {
                                remove: {
                                    trigger: {
                                        target: 'useCardToBefore',
                                    },
                                    forced: true,
                                    priority: 15,
                                    filter: function (event, player) {
                                        return event.card && event.card.name == 'qizhengxiangsheng';
                                    },
                                    content: function () {
                                        trigger.cancel();
                                    },
                                    ai: {
                                        effect: {
                                            target: function (card, player, target) {
                                                if (card && card.name == 'qizhengxiangsheng') return 'zerotarget';
                                            },
                                        },
                                    },
                                    sub: true,
                                    '_priority': 1500,
                                },
                                global: {
                                    trigger: {
                                        player: 'useCardToPlayered',
                                    },
                                    forced: true,
                                    popup: false,
                                    filter: function (event, player) {
                                        return event.card.name == 'qizhengxiangsheng';
                                    },
                                    content: function () {
                                        'step 0'
                                        var target = trigger.target;
                                        event.target = target;
                                        player.chooseControl('奇兵', '正兵').set('prompt', '请选择' + get.translation(target) + '的标记').set('choice', function () {
                                            var e1 = 1.5 * get.sgn(get.damageEffect(target, player, target));
                                            var e2 = 0;
                                            if (target.countGainableCards(player, 'h') > 0 && !target.hasSkillTag('noh')) e2 = -1;
                                            var es = target.getGainableCards(player, 'e');
                                            if (es.length) e2 = Math.min(e2, function () {
                                                var max = 0;
                                                for (var i of es) max = Math.max(max, get.value(i, target))
                                                return -max / 4;
                                            }());
                                            if (Math.abs(e1 - e2) <= 0.3) return Math.random() < 0.5 ? '奇兵' : '正兵';
                                            if (e1 < e2) return '奇兵';
                                            return '正兵';
                                        }()).set('ai', function () {
                                            return _status.event.choice;
                                        });
                                        'step 1'
                                        var map = trigger.getParent().customArgs, id = target.playerid;
                                        if (!map[id]) map[id] = {};
                                        map[id].qizheng_name = result.control;
                                    },
                                    sub: true,
                                },
                                rewrite: {
                                    audio: 'tianzuo',
                                    trigger: {
                                        global: 'useCardToTargeted',
                                    },
                                    filter: function (event, player, target) {
                                        return event.card.name == 'qizhengxiangsheng' && event.target != player;
                                    },
                                    logTarget: 'target',
                                    'prompt2': '观看其手牌并修改“奇正相生”标记',
                                    content: function () {
                                        'step 0'
                                        var target = trigger.target;
                                        event.target = target;
                                        if (player != target && target.countCards('h') > 0) player.viewHandcards(target);
                                        player.chooseControl('奇兵', '正兵').set('prompt', '请选择' + get.translation(target) + '的标记').set('choice', function () {
                                            var shas = target.getCards('h', 'sha'),
                                                shans = target.getCards('h', 'shan');
                                            var e1 = 1.5 * get.sgn(get.damageEffect(target, player, target));
                                            var e2 = 0;
                                            if (target.countGainableCards(player, 'h') > 0 && !target.hasSkillTag('noh')) e2 = -1;
                                            var es = target.getGainableCards(player, 'e');
                                            if (es.length) e2 = Math.min(e2, function () {
                                                var max = 0;
                                                for (var i of es) max = Math.max(max, get.value(i, target))
                                                return -max / 4;
                                            }());
                                            if (get.attitude(player, target) > 0) {
                                                if (shas.length >= Math.max(1, shans.length)) return '奇兵';
                                                if (shans.length > shas.length) return '正兵';
                                                return e1 > e2 ? '奇兵' : '正兵';
                                            }
                                            if (shas.length) e1 = -0.5;
                                            if (shans.length) e2 = -0.7;
                                            if (Math.abs(e1 - e2) <= 0.3) return Math.random() < 0.5 ? '奇兵' : '正兵';
                                            var rand = Math.random();
                                            if (e1 < e2) return rand < 0.1 ? '奇兵' : '正兵';
                                            return rand < 0.1 ? '正兵' : '奇兵';
                                        }()).set('ai', () => (_status.event.choice));
                                        'step 1'
                                        var map = trigger.getParent().customArgs, id = target.playerid;
                                        if (!map[id]) map[id] = {};
                                        map[id].qizheng_name = result.control;
                                        map[id].qizheng_aibuff = get.attitude(player, target) > 0;
                                    },
                                    sub: true,
                                },
                            },
                        },
                        nv_lingce: {
                            audio: 'lingce',
                            trigger: {global: 'useCard'},
                            forced: true,
                            filter: function (event, player) {
                                return (event.card.name == 'qizhengxiangsheng' || get.zhinangs().contains(event.card.name) || player.getStorage('nv_dinghan').contains(event.card.name));
                            },
                            content: function () {
                                player.draw().gaintag = ['nv_lingce'];
                            },
                            group: 'nv_lingce_clear',
                            subSkill: {
                                clear: {
                                    mod: {
                                        ignoredHandcard: function (card, player) {
                                            if (card.hasGaintag('nv_lingce')) {
                                                return true;
                                            }
                                        },
                                    },
                                    sub: true,
                                    trigger: {
                                        player: "phaseJieshuEnd",
                                    },
                                    forced: true,
                                    direct: true,
                                    charlotte: true,
                                    content: function () {
                                        player.removeGaintag('nv_lingce');
                                    },
                                },
                            },
                        },
                        nv_dinghan: {
                            audio: 'dinghan',
                            trigger: {
                                target: 'useCardToTarget',
                                player: 'addJudgeBefore',
                            },
                            forced: true,
                            locked: false,
                            filter: function (event, player) {
                                if (event.name == 'useCardToTarget' && get.type(event.card, null, false) != 'trick') return false;
                                return !player.getStorage('nv_dinghan').contains(event.card.name);
                            },
                            content: function () {
                                player.markAuto('nv_dinghan', [trigger.card.name]);
                                if (trigger.name == 'addJudge') {
                                    trigger.cancel();
                                    var owner = get.owner(trigger.card);
                                    if (owner && owner.getCards('hej').contains(trigger.card)) owner.lose(trigger.card, ui.discardPile);
                                    else game.cardsDiscard(trigger.card);
                                    game.log(trigger.card, '进入了弃牌堆');
                                } else {
                                    trigger.targets.remove(player);
                                    trigger.getParent().triggeredTargets2.remove(player);
                                    trigger.untrigger();
                                }
                            },
                            onremove: true,
                            intro: {content: '已记录牌名：$'},
                            group: 'nv_dinghan_add',
                            subSkill: {
                                add: {
                                    trigger: {player: 'phaseBegin'},
                                    direct: true,
                                    content: function () {
                                        'step 0'
                                        var dialog = [get.prompt('nv_dinghan')];
                                        list1 = player.getStorage('nv_dinghan'), list2 = lib.inpile.filter(function (i) {
                                            return get.type2(i, false) == 'trick' && !list1.contains(i);
                                        });
                                        if (list1.length) {
                                            dialog.push('<div class="text center">已记录</div>');
                                            dialog.push([list1, 'vcard']);
                                        }
                                        if (list2.length) {
                                            dialog.push('<div class="text center">未记录</div>');
                                            dialog.push([list2, 'vcard']);
                                        }
                                        player.chooseButton(dialog).set('ai', function (button) {
                                            var player = _status.event.player, name = button.link[2];
                                            if (player.getStorage('nv_dinghan').contains(name)) {
                                                return -get.effect(player, {name: name}, player, player);
                                            } else {
                                                return get.effect(player, {name: name}, player, player) * (1 + player.countCards('hs', name));
                                            }
                                        });
                                        'step 1'
                                        if (result.bool) {
                                            player.logSkill('nv_dinghan');
                                            var name = result.links[0][2];
                                            if (player.getStorage('nv_dinghan').contains(name)) {
                                                player.unmarkAuto('nv_dinghan', [name]);
                                                game.log(player, '从定汉记录中移除了', '#y' + get.translation(name));
                                            } else {
                                                player.markAuto('nv_dinghan', [name]);
                                                game.log(player, '向定汉记录中添加了', '#y' + get.translation(name));
                                            }
                                            game.delayx();
                                        }
                                    },
                                },
                            },
                        },
                        nv_duorui: {
                            audio: 'drlt_duorui',
                            init: function (player) {
                                if (!player.additionalSkills['nv_duorui']) player.additionalSkills['nv_duorui'] = [];
                                if (!player.storage.nv_duorui) player.storage.nv_duorui = 0;
                            },
                            trigger: {player: 'useCardToPlayered'},
                            direct: true,
                            filter: function (event, player) {
                                if (player.additionalSkills.nv_duorui) return player != event.target && event.target.isIn() && player.additionalSkills.nv_duorui.length < 3;
                                else return player != event.target && event.target.isIn();
                            },
                            check: function (event, player) {
                                return get.attitude(player, event.target) < 0;
                            },
                            content: function () {
                                'step 0'
                                var controls = [];
                                var skills = trigger.target.get('s', false, false);
                                for (i = 0; i < skills.length; i++) {
                                    var info = lib.skill[skills[i]];
                                    if (!info) continue;
                                    if (!lib.translate[skills[i]]) continue;
                                    if (!lib.translate[skills[i] + '_info']) continue;
                                    if (!controls.contains(skills[i])) {
                                        controls.push(skills[i]);
                                    }
                                }
                                if (controls.length >= 1) {
                                    player.chooseControl(controls, 'cancel').set('ai', function () {
                                        if (get.attitude(_status.event.player, trigger.target) > 0) return false;
                                        return Math.floor(Math.random() * controls.length);
                                    }).set('prompt', '可获得' + get.translation(trigger.target) + '的一个技能');
                                }
                                ;
                                'step 1'
                                if (result.control) {
                                    player.logSkill('nv_duorui', trigger.target);
                                    trigger.target.storage.nv_duorui = true;
                                    trigger.target.popup(result.control);
                                    // trigger.target.disableSkill('nv_duorui', [result.control]);
                                    player.addAdditionalSkill('nv_duorui', result.control, true);
                                    if (player.additionalSkills['nv_duorui']) {
                                        player.storage.nv_duorui = player.additionalSkills['nv_duorui'].length;
                                        player.markSkill('nv_duorui');
                                    }
                                    game.log(trigger.target, '技能【' + get.translation(result.control) + '】被', player, '复制');
                                }
                                ;
                            },
                            ai: {
                                threaten: 0.4,
                            },
                            mark: true,
                            marktext: '锐',
                            intro: {
                                content: function (storage, player) {
                                    return get.translation(player.additionalSkills['nv_duorui']);
                                },
                                name: '已抢到的技能',
                            },
                            group: ['nv_duorui_lose'],
                            subSkill: {
                                lose: {
                                    trigger: {
                                        player: 'phaseEnd',
                                    },
                                    priority: 10,
                                    direct: true,
                                    charlotte: true,
                                    popup: false,
                                    filter: function (event, player) {
                                        if (player.additionalSkills['nv_duorui']) {
                                            player.storage.nv_duorui = player.additionalSkills['nv_duorui'].length;
                                            player.markSkill('nv_duorui');
                                            return player.additionalSkills['nv_duorui'].length;
                                        } else return false;
                                    },
                                    content: function () {
                                        'step 0'
                                        var skills = player.additionalSkills['nv_duorui'];
                                        player.logSkill('nv_duorui');
                                        game.log(player, '失去了以下技能：', '#g' + get.translation(skills));
                                        var num = skills.length;
                                        for (var skill of skills) {
                                            player.removeSkill('nv_duorui',[skill]);
                                        }
                                        player.addAdditionalSkill(skill,'nv_duorui')
                                        player.draw(num);
                                    },
                                    sub: true,
                                },

                            },
                        },
                        nv_huiwan: {
                            audio: 'rezhiheng',
                            enable: 'phaseUse',
                            position: 'he',
                            discard: false,
                            usable: 1,
                            lose: false,
                            delay: false,
                            selectCard: [1, Infinity],
                            filterCard: function (card, player, event) {
                                event = event || _status.event;
                                if (typeof event != 'string') event = event.getParent().name;
                                var mod = game.checkMod(card, player, event, 'unchanged', 'cardDiscardable', player);
                                if (mod != 'unchanged') return mod;
                                return true;
                            },
                            prompt: '出牌阶段限一次。你可以弃置任意张牌并从牌堆或弃牌堆中获得等量的任意牌。若你弃置弃置了所有手牌，则你多选一张牌',
                            check: function (card) {
                                var player = _status.event.player;
                                if (get.position(card) == 'h' && !player.countCards('h', 'du') && (player.hp > 2 || !player.countCards('h', function (card) {
                                    return get.value(card) >= 8;
                                }))
                                ) {
                                    return 1;
                                }
                                return 6 - get.value(card);
                            },
                            filter: function (event, player) {
                                return player.countCards('he');
                            },
                            content: function () {
                                'step 0'
                                player.discard(cards);
                                event.getNum = 1;
                                var hs = player.getCards('h');
                                if (!hs.length) event.getNum = 0;
                                for (var i = 0; i < hs.length; i++) {
                                    if (!cards.contains(hs[i])) {
                                        event.getNum = 0;
                                        break;
                                    }
                                }
                                'step 1'
                                var card_list = [];
                                for (var i of ui.cardPile.childNodes) {
                                    card_list.push(i);
                                }
                                for (var i of ui.discardPile.childNodes) {
                                    card_list.push(i);
                                }
                                card_list.sort((a, b) => {
                                    if (a.name !== b.name) {
                                        return a.name.localeCompare(b.name);
                                    } else if (a.number !== b.number) {
                                        return a.number - b.number;
                                    } else {
                                        return a.suit - b.suit;
                                    }
                                });
                                var dialog = ui.create.dialog('任选' + get.cnNumber(cards.length + event.getNum) + '张牌并获得', [card_list, 'vcard']);
                                player.chooseButton(dialog, cards.length + event.getNum, true).ai = function (button) {
                                    if (player.hp < 3) return get.name(button.link) == 'tao';
                                    return get.value(button.link);
                                };
                                'step 2'
                                game.playSkillAudio('nv_huiwan');
                                player.gain(result.links, 'draw');
                                game.log(player, '获得了', result.links.length, '张牌');
                            },
                            ai: {
                                order: function (item, player) {
                                    if (player.countCards('h') == 1) {
                                        if (player.countCards('h', 'tao') == 0 && player.countCards('h', 'wuzhong') == 0) return 10;
                                    }
                                    if (player.countCards('h', 'tao') > 0) {
                                        return get.order({name: 'tao'}) - 1;
                                    }
                                    return 0.5;
                                },
                                result: {
                                    player: 1,
                                },
                                threaten: 3,
                            },
                        },
                        nv_quanji: {
                            audio: 'xinquanji',
                            trigger: {
                                global: 'gainAfter',
                                player: ['damageEnd', 'loseAsyncAfter', 'phaseUseEnd'],
                            },
                            frequent: true,
                            filter: function (event, player) {
                                if (event.name == 'phaseUse') return player.countCards('h') > player.hp;
                                if (event.name == 'damage') return true;
                                if (event.name == 'loseAsync') {
                                    if (event.type != 'gain' || event.giver) return false;
                                    var cards = event.getl(player).cards2;
                                    return game.hasPlayer(function (current) {
                                        if (current == player) return false;
                                        var cardsx = event.getg(current);
                                        for (var i of cardsx) {
                                            if (cards.contains(i)) return true;
                                        }
                                        return false;
                                    });
                                }
                                if (player == event.player) return false;
                                if (event.giver || event.getParent().name == 'gift') return false;
                                var evt = event.getl(player);
                                return evt && evt.cards2 && evt.cards2.length > 0;
                            },
                            content: function () {
                                'step 0'
                                event.count = (trigger.name == 'damage' ? trigger.num : 1);
                                'step 1'
                                event.count--;
                                player.draw();
                                'step 2'
                                var hs = player.getCards('h');
                                if (hs.length) {
                                    if (hs.length == 1) event._result = {bool: true, cards: hs};
                                    else player.chooseCard('h', true, '选择一张手牌作为“权”');
                                } else event.goto(4);
                                'step 3'
                                if (result.bool && result.cards && result.cards.length) {
                                    player.addToExpansion(result.cards, 'giveAuto', player).gaintag.add('nv_quanji');
                                }
                                'step 4'
                                if (event.count > 0 && player.hasSkill('nv_quanji')) {
                                    player.chooseBool(get.prompt2('nv_quanji')).set('frequentSkill', 'nv_quanji');
                                } else event.finish();
                                'step 5'
                                if (result.bool) {
                                    player.logSkill('nv_quanji');
                                    event.goto(1);
                                }
                            },
                            locked: false,
                            onremove: function (player, skill) {
                                var cards = player.getExpansions(skill);
                                if (cards.length) player.loseToDiscardpile(cards);
                            },
                            intro: {
                                markcount: 'expansion',
                                mark: function (dialog, content, player) {
                                    var content = player.getExpansions('nv_quanji');
                                    if (content && content.length) {
                                        if (player == game.me || player.isUnderControl()) {
                                            dialog.addAuto(content);
                                        } else {
                                            return '共有' + get.cnNumber(content.length) + '张“权”';
                                        }
                                    }
                                },
                                content: function (content, player) {
                                    var content = player.getExpansions('nv_quanji');
                                    if (content && content.length) {
                                        if (player == game.me || player.isUnderControl()) {
                                            return get.translation(content);
                                        }
                                        return '共有' + get.cnNumber(content.length) + '张“权”';
                                    }
                                }
                            },
                            mod: {
                                maxHandcard: function (player, num) {
                                    return num + player.getExpansions('nv_quanji').length;
                                },
                            },
                            ai: {
                                maixie: true,
                                maixie_hp: true,
                                threaten: 0.8,
                                effect: {
                                    target: function (card, player, target) {
                                        if (get.tag(card, 'damage') && !target.storage.xinzili) {
                                            if (player.hasSkillTag('jueqing', false, target)) return [1, -2];
                                            if (!target.hasFriend()) return;
                                            if (target.hp >= 4) return [0.5, get.tag(card, 'damage') * 2];
                                            if (!target.hasSkill('xinpaiyi') && target.hp > 1) return [0.5, get.tag(card, 'damage') * 1.5];
                                            if (target.hp == 3) return [0.5, get.tag(card, 'damage') * 1.5];
                                            if (target.hp == 2) return [1, get.tag(card, 'damage') * 0.5];
                                        }
                                    },
                                },
                            },
                            group: ['nv_quanji_start', 'nv_quanji_exchange'],
                            subSkill: {
                                start: {
                                    sub: true,
                                    audio: 'zyquanji',
                                    trigger: {
                                        global: "gameDrawBefore",
                                    },
                                    forced: true,
                                    content: function () {
                                        var num = 0;
                                        for (var i of game.players) {
                                            if (i.group == player.group) num++;
                                        }
                                        player.addToExpansion(get.cards(num), 'draw').gaintag.add('nv_quanji');
                                    },
                                },
                                exchange: {
                                    sub: true,
                                    audio: 'clanxieshu',
                                    enable: "phaseUse",
                                    usable: 1,
                                    lose: false,
                                    discard: false,
                                    delay: false,
                                    selectCard: [1, Infinity],
                                    filterCard: true,
                                    filter: function (event, player) {
                                        return player.getExpansions('nv_quanji').length > 0;
                                    },
                                    prompt: "用任意数量的手牌与等量的“权”交换",
                                    content: function () {
                                        'step 0'
                                        player.addToExpansion(cards, 'hidden', player).gaintag.add('nv_quanji');
                                        'step 1'
                                        player.chooseCardButton(player.getExpansions('nv_quanji'), '选择' + get.cnNumber(cards.length) + '张牌作为手牌', cards.length, true).ai = function (button) {
                                            return get.value(button.link);
                                        }
                                        'step 2'
                                        player.gain(result.links, 'hidden');
                                    },
                                    ai: {
                                        order: 5,
                                        result: {
                                            player: 1,
                                        },
                                    },
                                },
                            },
                        },
                        nv_paiyi: {
                            audio: 'xinpaiyi',
                            enable: 'phaseUse',
                            filter: function (event, player) {
                                return player.getExpansions('nv_quanji').length > 0 && (!player.hasSkill('nv_paiyi_0') || !player.hasSkill('nv_paiyi_1'))
                            },
                            chooseButton: {
                                check: function (button) {
                                    if (typeof button.link == 'object') return 1;
                                    var player = _status.event.player,
                                        num = player.getExpansions('nv_quanji').length - 1;
                                    if (button.link == 1) {
                                        if (game.countPlayer(function (current) {
                                            return get.damageEffect(current, player, player) > 0;
                                        }) < num) return 0.5;
                                        return 2;
                                    }
                                    if (num < 2) return 0;
                                    return 1;
                                },
                                dialog: function (event, player) {
                                    var dialog = ui.create.dialog('权计', 'hidden');
                                    var table = document.createElement('div');
                                    table.classList.add('add-setting');
                                    table.style.margin = '0';
                                    table.style.width = '100%';
                                    table.style.position = 'relative';
                                    var list = ['摸牌', '造成伤害'];
                                    dialog.add([list.map((item, i) => {
                                        return [i, item];
                                    }), 'tdnodes']);
                                    dialog.add(player.getExpansions('nv_quanji'));
                                    return dialog;
                                },
                                select: 2,
                                filter: function (button, player) {
                                    if (ui.selected.buttons.length) {
                                        if (typeof button.link != 'object') {
                                            if (button.link == 0) {
                                                return !player.hasSkill('nv_paiyi_0') && (typeof ui.selected.buttons[0].link) != (typeof button.link);
                                            }
                                            if (button.link == 1) {
                                                return !player.hasSkill('nv_paiyi_1') && (typeof ui.selected.buttons[0].link) != (typeof button.link);
                                            }
                                        }
                                        return (typeof ui.selected.buttons[0].link) != (typeof button.link);
                                    } else if (typeof button.link != 'object') {
                                        if (button.link == 0) {
                                            return !player.hasSkill('nv_paiyi_0');
                                        }
                                        if (button.link == 1) {
                                            return !player.hasSkill('nv_paiyi_1');
                                        }
                                    }
                                    return true;
                                },
                                backup: function (links) {
                                    if (typeof links[0] == 'object') links.reverse();
                                    var next = get.copy(lib.skill['nv_paiyi_backup' + links[0]]);
                                    next.card = links[1];
                                    return next;
                                },
                                prompt: function (links, player) {
                                    if (typeof links[0] == 'object') links.reverse();
                                    var num = get.cnNumber(Math.max(1, player.getExpansions('nv_quanji').length - 1)),
                                        card = get.translation(links[1]);
                                    if (links[0] == 0) return '移去' + card + '并令一名角色摸' + num + '张牌';
                                    return '移去' + card + '并对至多' + num + '名角色造成1点伤害';
                                },
                            },
                            ai: {
                                order: 1,
                                result: {
                                    player: 1,
                                },
                            },
                            subSkill: {
                                0: {},
                                1: {},
                                backup0: {
                                    audio: 'xinpaiyi',
                                    filterCard: () => false,
                                    selectCard: -1,
                                    filterTarget: true,
                                    delay: false,
                                    content: function () {
                                        'step 0'
                                        player.addTempSkill('nv_paiyi_0', 'phaseUseEnd');
                                        var card = lib.skill.nv_paiyi_backup.card;
                                        player.loseToDiscardpile(card);
                                        'step 1'
                                        target.draw(Math.max(1, player.getExpansions('nv_quanji').length));
                                    },
                                    ai: {
                                        result: {
                                            target: function (player, target) {
                                                if (target.hasSkill('nogain')) return 0;
                                                if (player == target && !player.needsToDiscard()) return 3;
                                                return 1;
                                            },
                                        },
                                    },
                                },
                                backup1: {
                                    audio: 'xinpaiyi',
                                    filterCard: () => false,
                                    selectCard: -1,
                                    filterTarget: true,
                                    delay: false,
                                    multitarget: true,
                                    multiline: true,
                                    selectTarget: function () {
                                        return [1, Math.max(1, _status.event.player.getExpansions('nv_quanji').length - 1)];
                                    },
                                    content: function () {
                                        'step 0'
                                        targets.sortBySeat();
                                        player.addTempSkill('nv_paiyi_1', 'phaseUseEnd');
                                        var card = lib.skill.nv_paiyi_backup.card;
                                        player.loseToDiscardpile(card);
                                        'step 1'
                                        for (var i of targets) i.damage();
                                    },
                                    ai: {
                                        tag: {
                                            damage: 1,
                                        },
                                        result: {
                                            target: -1.5,
                                        },
                                    },
                                },
                            },
                        },
                        nv_bidang: {
                            audio: 'clanbaozu',
                            trigger: {
                                global: "phaseBegin",
                            },
                            check: function (event, player) {
                                var att = get.attitude(player, event.player);
                                if (att < 0) {
                                    var nh1 = event.player.countCards('h');
                                    var nh2 = player.countCards('h');
                                    return nh1 <= 2 && nh2 > nh1 + 1;
                                }
                                if (att > 0 && event.player.hasJudge('lebu') && event.player.countCards('h') > event.player.hp + 1) return true;
                                return false;
                            },
                            logTarget: "player",
                            filter: function (event, player) {
                                return event.player != player && player.canCompare(event.player);
                            },
                            content: function () {
                                "step 0"
                                player.chooseToCompare(trigger.player);
                                "step 1"
                                if (result.bool) {
                                    trigger.player.skip('phaseZhunbei');
                                    trigger.player.skip('phaseJudge');
                                }
                            },
                            ai: {
                                expose: 0.2,
                            },
                        },
                        nv_tianren: {
                            trigger: {global: ['loseAfter', 'cardsDiscardAfter', 'loseAsyncAfter']},
                            forced: true,
                            filter: function (event, player) {
                                if (event.name.indexOf('lose') == 0) {
                                    if (event.getlx === false || event.position != ui.discardPile) return false;
                                }
                                for (var i of event.cards) {
                                    var owner = false;
                                    if (event.hs && event.hs.contains(i)) owner = event.player;
                                    var type = get.type(i, null, owner);
                                    if (type == 'basic' || type == 'trick') return true;
                                }
                                return false;
                            },
                            content: function () {
                                var num = 0;
                                for (var i of trigger.cards) {
                                    var owner = false;
                                    if (trigger.hs && trigger.hs.contains(i)) owner = trigger.player;
                                    var type = get.type(i, null, owner);
                                    if (type == 'basic' || type == 'trick') num++;
                                }
                                player.addMark('nv_tianren', num);
                            },
                            group: 'nv_tianren_maxHp',
                            intro: {content: 'mark'},
                            subSkill: {
                                maxHp: {
                                    audio: 'tianren',
                                    trigger: {player: ['nv_tianrenAfter', 'gainMaxHpAfter', 'loseMaxHpAfter']},
                                    forced: true,
                                    filter: function (event, player) {
                                        return player.countMark('nv_tianren') >= player.maxHp;
                                    },
                                    content: function () {
                                        player.removeMark('nv_tianren', player.maxHp);
                                        player.gainMaxHp();
                                        player.changeHujia(1);
                                        player.draw(2);
                                    },
                                },
                            },
                        },
                        nv_pingxiang: {
                            audio: 'pingxiang',
                            enable: 'phaseUse',
                            limited: true,
                            skillAnimation: true,
                            animationColor: 'fire',
                            filter: function (event, player) {
                                return player.maxHp > 9;
                            },
                            content: function () {
                                'step 0'
                                player.awakenSkill('nv_pingxiang');
                                player.loseMaxHp(9);
                                event.num = 0;
                                'step 1'
                                player.chooseTarget('请选择目标，对其造成一点火属性伤害（' + (event.num == 9 ? '⑨' : event.num) + '/9）', false, lib.filter.notMe).ai = function (target) {
                                    return -get.attitude(_status.event.player, target);
                                };
                                event.num++;
                                'step 2'
                                if (result.bool) {
                                    result.targets[0].damage(1, 'fire');
                                }
                                'step 3'
                                if (result.bool && event.num < 9) event.goto(1);
                                else {
                                    player.removeSkill('jiufa');
                                    player.addSkill('nv_pingxiang_effect');
                                }
                            },
                            ai: {
                                fireAttack: true,
                                order: 7,
                                result: {
                                    player: 1,
                                },
                            },
                            subSkill: {
                                effect: {
                                    marktext: '襄',
                                    intro: {content: '手牌上限基数改为体力上限'},
                                    mod: {
                                        maxHandcardBase: function (player) {
                                            return player.maxHp;
                                        },
                                    },
                                },
                            },
                        },
                        nv_naotan:{},
                    }, // 技能（必填）
                    translate: {
                        nv_xusheng: '徐盛',
                        nv_xusheng_prefix: '女',
                        nv_ganning: '甘宁',
                        nv_ganning_prefix: '女',
                        nv_huangzhong: '黄忠',
                        nv_huangzhong_prefix: '女',
                        nv_guojia: '郭嘉',
                        nv_guojia_prefix: '女',
                        nv_xunyu: '荀彧',
                        nv_xunyu_prefix: '女',
                        nv_sunquan: '孙权',
                        nv_sunquan_prefix: '女',
                        nv_zhangliao: '张辽',
                        nv_zhangliao_prefix: '女',
                        nv_zhonghui: '钟会',
                        nv_zhonghui_prefix: '女',
                        nv_jiangwei: '姜维',
                        nv_jiangwei_prefix: '女',
                        nv_paiyi_backup: '排异',

                        nv_pojun: '破军',
                        nv_pojun_info: '①当你使用【杀】指定一个目标后，你可以获得其至多X张牌（X为其体力上限）。若如此做，本阶段结束后，若该角色未死亡，你交给其Y张牌（Y为你从该角色获得的牌的数量）。②当你因执行【杀】的效果而对一名角色造成伤害时，若该角色的手牌数不大于你，则此伤害+1。',
                        nv_xushi: '蓄势',
                        nv_xushi_info: '①结束阶段，若你本回合未造成伤害，则你获得一点护甲和一个“蓄”标记，并从牌堆或弃牌堆中获得一张【杀】。②你可以令下一张【杀】的伤害值基数+X（X为“蓄”标记的数量）。',
                        nv_poxi: '魄袭',
                        nv_poxi_info: '出牌阶段限一次，你可以观看一名其他角色的手牌，然后你可以弃置你与其手牌中的共四张牌。若如此做，根据此次弃置你的牌的数量执行以下效果：零张，流失一点体力；一张，你本回合手牌上限-1；两张，你本回合使用【杀】的次数上限+1；三张，你回复一点体力且获得一点护甲；四张，你摸五张牌。',
                        nv_jieying: '劫营',
                        nv_jieying_mark: '劫营',
                        nv_jieying_info: '回合开始时，若场上没有拥有“营”标记的角色，你获得1个“营”标记；结束阶段，你可以将你的一个“营”标记交给一名角色；有“营”标记的角色摸牌阶段多摸一张牌，出牌阶段使用【杀】的次数上限+1，手牌上限+1。有“营”的其他角色出牌阶段结束后/弃牌阶段开始前/回合结束后，其移去“营”标记，然后你获得其所有手牌。',
                        nv_liegong: '烈弓',
                        nv_liegong_info: '你的【杀】无法被响应且你的手牌无视距离。当你使用牌时，你获得一个“烈”标记。你使用【杀】的次数最多为X，且你使用的【杀】对其他角色造成的伤害+X。回合结束后，你移除所有“烈”标记，并摸X张牌 (其中X为“烈”标记的数量且最多为3)。',
                        nv_huishi: '慧识',
                        nv_huishi_info: '出牌阶段限一次。若你的体力上限小于10，你可进行判定牌不置入弃牌堆的判定。若判定结果与本次发动技能时的其他判定结果的花色均不相同且你的体力上限小于10，则你加1点体力上限并回复一点体力，且可以重复此流程。然后你将所有位于处理区的判定牌交给一名角色，且这些牌本回合不计入手牌上限。若其手牌数为全场最多，则你减1点体力上限。',
                        nv_huishiPlus: '辉逝',
                        nv_huishiPlus_info: '限定技，出牌阶段，你可以选择一名角色：若其有未发动过的觉醒技，则你令其发动这些觉醒技时无视原有条件；否则其摸四张牌。然后你减2点体力上限。',
                        nv_tianyi: '天翊',
                        nv_tianyi_info: '觉醒技，准备阶段，若场上的所有存活角色均于本局游戏内受到过伤害，则你加2点体力上限并回复1点体力，然后令一名角色获得技能〖佐幸〗。',
                        nv_zuoxing: '佐幸',
                        nv_zuoxing_info: '出牌阶段限一次，若令你获得〖佐幸〗的角色存活且体力上限大于1，则你可以令其减1点体力上限，并视为使用一张基本牌或普通锦囊牌。',
                        nv_lingce: '灵策',
                        nv_lingce_info: '锁定技。当有【奇正相生】或智囊或〖定汉①〗记录过的锦囊牌被使用时，你摸一张牌。你通过〖灵策〗获得的牌直到你的下个结束阶段前不计入手牌上限。',
                        nv_dinghan: '定汉',
                        nv_dinghan_info: '①当你成为未记录过的普通锦囊牌的目标时，或有未记录过的延时锦囊牌进入你的判定区时，你记录此牌名并取消之。②准备阶段，你可在〖定汉①〗的记录中添加或减少一种锦囊牌的牌名。',
                        nv_duorui: '夺锐',
                        nv_duorui_info: '①当你使用牌指定其他角色为目标后，你可复制该角色的一个技能直到你死亡为止。你以此法获得的技能不超过3个。②回合结束时，你失去所有通过〖夺锐〗获得的技能，并摸等量的牌。',
                        nv_huiwan: '会玩',
                        nv_huiwan_info: '出牌阶段限一次。你可以弃置任意张牌并从牌堆或弃牌堆中获得等量的任意牌。若你在发动〖会玩〗时弃置了所有手牌，则你多选一张牌。',
                        nv_quanji: '权计',
                        nv_quanji_info: '①游戏开始时，你将牌堆顶与你相同势力角色数等量的牌置于你的武将牌上，称为“权”。②出牌阶段结束时，若你的手牌数大于体力值，或当你受到1点伤害后，或其他角色不因你的赠予或交给而得到你的牌后，你可以摸一张牌，然后将一张手牌置入“权”。你的手牌上限+X（X为“权”的数量）。③出牌阶段限一次，你可以用任意数量的手牌与等量的“权”交换。',
                        nv_paiyi: '排异',
                        nv_paiyi_info: '出牌阶段每项各限一次，你可移去一张“权”并选择一项：①令一名角色摸X张牌。②对至多X名角色各造成1点伤害（X为“权”数）。',
                        nv_bidang: '庇党',
                        nv_bidang_info: '其他角色的回合开始前，你可以与该角色拼点。若你赢，该角色跳过准备和判定阶段。',
                        nv_pingxiang: '平襄',
                        nv_pingxiang_info: '限定技。出牌阶段，若你的体力上限大于⑨，则你可减⑨点体力上限，至多造成⑨点火属性伤害，然后失去〖九伐〗，并将手牌上限基数改为体力上限直到游戏结束。',
                    }, // 翻译（必填）
                    perfectPair: {}, // 珠联璧合武将（选填）
                };
                if (lib.device || lib.node) {
                    for (var i in nv_wujiang.character) {
                        nv_wujiang.character[i][4].push('ext:武将娘化/' + i + '.jpg');
                    }
                } else {
                    for (var i in nv_wujiang.character) {
                        nv_wujiang.character[i][4].push('db:extension-武将娘化:' + i + '.jpg');
                    }
                }
                // 由于以此法加入的武将包武将图片是用源文件的，所以要用此法改变路径
                return nv_wujiang;
            });
            lib.config.all.characters.push('nv_wujiang');
            if (!lib.config.characters.contains('nv_wujiang')) lib.config.characters.push('nv_wujiang');
            lib.translate['nv_wujiang_character_config'] = '武将娘化';

        },
        help: {},
        config: {},
        package: {
            character: {
                character: {},
                characterTitle: {},
                translate: {},
            },
            card: {
                card: {},
                translate: {},
                list: [],
            },
            skill: {
                skill: {},
                translate: {},
            },
            intro: '武将女化包，小修改版本，鸣谢𝓐𝓲𝓻𝓘𝓻𝓸𝓷𝔂',
            author: '𝑩𝒆𝒊𝒚𝒖',
            diskURL: '',
            forumURL: '',
            version: '1.2.2fix',
        },
        files: {
            'character': ['nv_zhonghui.jpg', 'nv_sunquan.jpg', 'nv_zhangliao.jpg', 'nv_xusheng.jpg', 'nv_huangzhong.jpg', 'nv_guojia.jpg', 'nv_ganning.jpg', 'nv_xunyu.jpg', 'nv_jiangwei.jpg'],
            'card': [],
            'skill': []
        }
    }
})